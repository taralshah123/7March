#include<linux/init.h>
#include<linux/module.h>
#include<linux/moduleparam.h>

//var array
int param_var[3] = {0,0,0};

// register
module_param_array(param_var, int,NULL, S_IRUSR | S_IWUSR);
/*void display(){
	printk(KERN_ALERT " TEST: param = %d",param_var);
}*/
static int hello_init(void){
//	printk(KERN_ALERT"TEST: Hello\n");
//	display();
	printk(KERN_ALERT " TEST: param = %d\n",param_var[0]);
	printk(KERN_ALERT " TEST: param = %d\n",param_var[1]);
	printk(KERN_ALERT " TEST: param = %d\n",param_var[2]);
	printk(KERN_ALERT"TEST: Hello\n");

	return 0;
}

static void hello_exit(void){
	printk(KERN_ALERT "TEST:Bye\n");
}

module_init(hello_init);
module_exit(hello_exit);

